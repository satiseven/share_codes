<?php

namespace App\Console\Commands\Telegram\NewOrderBot;

use Illuminate\Console\Command;
use Telegram\Bot\Laravel\Facades\Telegram;

class SetWebHookCommand extends Command
{
    protected $signature = 'deneme';

    protected $description = 'Command description';

    public function handle()
    {
        // TODO : bakılacak.

    }
}
