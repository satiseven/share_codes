<?php

namespace App\Enums\Currency;

class CurrencyEnum
{
    const TRY = 'TRY';
    const USD = 'USD';
    const AED = 'AED';
}
