<?php

namespace App\Enums\Auth;

class GuardEnum
{
    const USER  = 'user';
    const ADMIN = 'admin';
}
