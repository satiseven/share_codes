<?php

namespace App\Enums\Cache\Settings;

class SettingsCacheEnum
{
    const KEY = 'settings';
    const TTL = 60 * 60;
}
