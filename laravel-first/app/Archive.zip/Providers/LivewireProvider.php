<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Livewire\Livewire;

class LivewireProvider extends ServiceProvider
{
    public function register()
    {

    }

    public function boot()
    {
        //
    }
}
