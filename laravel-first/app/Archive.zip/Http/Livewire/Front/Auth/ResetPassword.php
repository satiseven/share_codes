<?php

namespace App\Http\Livewire\Front\Auth;

use Livewire\Component;

class ResetPassword extends Component
{
    public function render()
    {
        return view('livewire.front.auth.reset-password');
    }
}
